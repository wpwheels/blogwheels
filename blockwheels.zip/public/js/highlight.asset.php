<?php return array('dependencies' => array(), 'version' => 'd0c28c464bb40371c0f8');
