<?php return array('dependencies' => array(), 'version' => '43b278dafe28a21489e6');
