<?php return array('dependencies' => array(), 'version' => '959da085594327869cad');
