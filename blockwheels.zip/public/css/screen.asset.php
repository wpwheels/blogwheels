<?php return array('dependencies' => array(), 'version' => '196641f89905f5ca1f10');
