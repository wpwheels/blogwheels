<?php return array('dependencies' => array(), 'version' => '69cdca715c092db309d0');
