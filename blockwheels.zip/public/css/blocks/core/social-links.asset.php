<?php return array('dependencies' => array(), 'version' => 'c62cb23568ea7d0c04f2');
