<?php return array('dependencies' => array(), 'version' => '52d113698a4e5cd8a248');
