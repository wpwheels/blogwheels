<?php return array('dependencies' => array(), 'version' => '047a60ee0034670cb8b4');
