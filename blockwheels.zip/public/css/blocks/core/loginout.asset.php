<?php return array('dependencies' => array(), 'version' => '4b6995b921fec929035b');
