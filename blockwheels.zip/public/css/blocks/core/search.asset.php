<?php return array('dependencies' => array(), 'version' => '8f2e6d044b4e0f9dbe0c');
