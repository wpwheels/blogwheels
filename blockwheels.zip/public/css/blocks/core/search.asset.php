<?php return array('dependencies' => array(), 'version' => 'a31db4079a3616fce63e');
