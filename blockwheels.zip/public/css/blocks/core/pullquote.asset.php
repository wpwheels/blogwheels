<?php return array('dependencies' => array(), 'version' => '01225033b3972a6e8bdc');
