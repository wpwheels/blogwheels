<?php return array('dependencies' => array(), 'version' => 'b7843a031292b38796be');
