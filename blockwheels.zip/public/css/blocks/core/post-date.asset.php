<?php return array('dependencies' => array(), 'version' => '799bfb49a8b15f71a357');
