<?php return array('dependencies' => array(), 'version' => 'a4b31aa51e2d8450f793');
