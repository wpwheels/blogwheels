<?php return array('dependencies' => array(), 'version' => '9310d12be4be76728443');
