<?php return array('dependencies' => array(), 'version' => '7f50962b2aaccda898b8');
