<?php return array('dependencies' => array(), 'version' => 'efb5aca4a42664354b76');
