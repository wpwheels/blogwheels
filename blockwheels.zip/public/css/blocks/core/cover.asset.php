<?php return array('dependencies' => array(), 'version' => 'fb55e4daa4da5a54259d');
