<?php return array('dependencies' => array(), 'version' => '687d4d6aeb3a2d586019');
