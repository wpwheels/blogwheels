<?php return array('dependencies' => array(), 'version' => 'dfb3758deb157f3ba938');
