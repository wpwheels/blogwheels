<?php return array('dependencies' => array(), 'version' => '8280cfd5d1f6158a3d7a');
