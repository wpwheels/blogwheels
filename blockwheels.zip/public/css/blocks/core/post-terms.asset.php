<?php return array('dependencies' => array(), 'version' => 'f14f7ee2d85225e22d6f');
