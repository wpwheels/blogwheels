<?php return array('dependencies' => array(), 'version' => '3424db1331d1109adaa8');
