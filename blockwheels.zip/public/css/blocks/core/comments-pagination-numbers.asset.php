<?php return array('dependencies' => array(), 'version' => '4bc5441a6991c6f76512');
