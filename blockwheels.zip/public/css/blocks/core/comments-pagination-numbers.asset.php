<?php return array('dependencies' => array(), 'version' => '068cb5a6097bf0732e6d');
