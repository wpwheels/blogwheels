<?php return array('dependencies' => array(), 'version' => '52ac5fee956ced9b0b0e');
