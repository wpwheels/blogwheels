<?php return array('dependencies' => array(), 'version' => '64f839c52f54f528568f');
