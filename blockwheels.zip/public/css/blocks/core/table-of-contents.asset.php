<?php return array('dependencies' => array(), 'version' => '529780cbd05b0a474e9b');
