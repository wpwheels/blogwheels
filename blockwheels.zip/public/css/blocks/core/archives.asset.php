<?php return array('dependencies' => array(), 'version' => '9d4f8ec185e8ad5ca0af');
