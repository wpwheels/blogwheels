<?php return array('dependencies' => array(), 'version' => '29582e162c74703e3980');
