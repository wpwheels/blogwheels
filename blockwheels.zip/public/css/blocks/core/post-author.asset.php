<?php return array('dependencies' => array(), 'version' => 'dc5812a0117c7f64e949');
