<?php return array('dependencies' => array(), 'version' => 'ac2e510c14dc94d4c659');
