<?php return array('dependencies' => array(), 'version' => 'cb23e9770bcef5d3c9ac');
