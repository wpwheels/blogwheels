<?php return array('dependencies' => array(), 'version' => 'fcbfc667d49263e76f32');
