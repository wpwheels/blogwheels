<?php return array('dependencies' => array(), 'version' => 'd94d4a00d1e3a39df363');
