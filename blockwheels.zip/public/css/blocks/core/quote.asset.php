<?php return array('dependencies' => array(), 'version' => '993d951b628b95b3c368');
