<?php return array('dependencies' => array(), 'version' => 'f0320188872f2e7852f1');
