<?php return array('dependencies' => array(), 'version' => '621af19f3d1c8e419dfe');
