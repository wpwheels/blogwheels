<?php return array('dependencies' => array(), 'version' => 'cc91eed5ceecb28daf33');
