<?php return array('dependencies' => array(), 'version' => '0b2ec99f8b15cbc0efb8');
