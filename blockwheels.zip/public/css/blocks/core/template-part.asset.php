<?php return array('dependencies' => array(), 'version' => 'd150f65b0c965e43a4ea');
