<?php return array('dependencies' => array(), 'version' => '61825a303b69f6fb5ca3');
