<?php return array('dependencies' => array(), 'version' => 'e97c2b20f3e2a923f2be');
