<?php return array('dependencies' => array(), 'version' => '2cebc2ea32326342dc9a');
