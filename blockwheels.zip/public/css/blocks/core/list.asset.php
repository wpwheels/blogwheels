<?php return array('dependencies' => array(), 'version' => 'df313125f64358cc9a30');
