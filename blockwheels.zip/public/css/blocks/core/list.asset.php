<?php return array('dependencies' => array(), 'version' => '9f5ca74e41836168d47e');
