<?php return array('dependencies' => array(), 'version' => '02e0980b618191f04fed');
