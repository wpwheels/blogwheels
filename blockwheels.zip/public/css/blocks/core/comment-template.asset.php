<?php return array('dependencies' => array(), 'version' => '15d322fc350ad80155d6');
