<?php return array('dependencies' => array(), 'version' => '5a992b7b40e3094caace');
