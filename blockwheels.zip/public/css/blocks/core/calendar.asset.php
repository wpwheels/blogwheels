<?php return array('dependencies' => array(), 'version' => '973b2c58625a45aeac19');
