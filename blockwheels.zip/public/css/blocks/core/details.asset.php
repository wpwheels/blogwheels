<?php return array('dependencies' => array(), 'version' => '8a8830d772321994824e');
