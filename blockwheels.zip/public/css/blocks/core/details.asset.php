<?php return array('dependencies' => array(), 'version' => '144044169138b67ed389');
