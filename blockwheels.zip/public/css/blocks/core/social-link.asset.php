<?php return array('dependencies' => array(), 'version' => '8cbc649ea06670190d63');
