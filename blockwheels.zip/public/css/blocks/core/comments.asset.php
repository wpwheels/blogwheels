<?php return array('dependencies' => array(), 'version' => '0d210df1c923488d3115');
