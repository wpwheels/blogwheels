<?php return array('dependencies' => array(), 'version' => '758ff082d28d41f5501d');
