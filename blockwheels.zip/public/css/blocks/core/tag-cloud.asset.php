<?php return array('dependencies' => array(), 'version' => 'c2d794d73b83fbadec14');
