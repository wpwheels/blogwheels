<?php return array('dependencies' => array(), 'version' => '183d5a48615d94914c22');
