<?php return array('dependencies' => array(), 'version' => 'dd19cd42c777f1a38e12');
