<?php return array('dependencies' => array(), 'version' => '121156c211f20540840a');
