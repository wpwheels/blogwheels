<?php return array('dependencies' => array(), 'version' => 'b107bdcfcdae0b2338c5');
