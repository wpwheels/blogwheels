<?php return array('dependencies' => array(), 'version' => '92070265bdad4d26aea0');
