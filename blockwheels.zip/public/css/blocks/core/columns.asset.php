<?php return array('dependencies' => array(), 'version' => 'c32c0225e39f0ea1a034');
