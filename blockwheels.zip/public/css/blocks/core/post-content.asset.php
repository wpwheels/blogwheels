<?php return array('dependencies' => array(), 'version' => '0ea2838313cbe5dd7998');
