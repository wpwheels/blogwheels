<?php return array('dependencies' => array(), 'version' => '34d5152673e9d4013fe7');
