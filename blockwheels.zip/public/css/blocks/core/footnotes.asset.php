<?php return array('dependencies' => array(), 'version' => '7db67aab9afa6d0d848a');
