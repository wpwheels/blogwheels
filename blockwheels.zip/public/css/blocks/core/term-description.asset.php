<?php return array('dependencies' => array(), 'version' => '87a35591b6548d5aab95');
