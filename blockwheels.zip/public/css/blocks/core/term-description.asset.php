<?php return array('dependencies' => array(), 'version' => '02d3631c77df12c6f829');
