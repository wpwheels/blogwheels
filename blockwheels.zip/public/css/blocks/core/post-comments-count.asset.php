<?php return array('dependencies' => array(), 'version' => '0924fb487d15822bf1a5');
