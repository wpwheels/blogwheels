<?php return array('dependencies' => array(), 'version' => '26d63a5a4c689c14117b');
