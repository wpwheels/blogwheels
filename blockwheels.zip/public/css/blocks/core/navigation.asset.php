<?php return array('dependencies' => array(), 'version' => '89ad7f40e29710eb1b4b');
