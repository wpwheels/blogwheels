<?php return array('dependencies' => array(), 'version' => '0a7d21e6ce677a5b28a0');
