<?php return array('dependencies' => array(), 'version' => '64288fa9275e1898cc09');
