<?php return array('dependencies' => array(), 'version' => 'a8b01bb3e590fc7b4ee0');
