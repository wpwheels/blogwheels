<?php return array('dependencies' => array(), 'version' => '0a5bafac85eb1186f48f');
