<?php return array('dependencies' => array(), 'version' => '1aadc90deaabbd3e6c34');
