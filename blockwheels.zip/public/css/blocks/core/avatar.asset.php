<?php return array('dependencies' => array(), 'version' => 'a60976ef5ecf998425e2');
