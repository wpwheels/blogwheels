<?php return array('dependencies' => array(), 'version' => '6cdaaa8eb8b683e9c743');
