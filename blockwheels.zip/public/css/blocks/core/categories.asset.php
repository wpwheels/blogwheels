<?php return array('dependencies' => array(), 'version' => '98336dd32449430245a9');
