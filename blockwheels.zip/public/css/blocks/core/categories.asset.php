<?php return array('dependencies' => array(), 'version' => 'fae9f41337c3eab8a920');
