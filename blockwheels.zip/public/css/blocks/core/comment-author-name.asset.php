<?php return array('dependencies' => array(), 'version' => '95e700d144a1fb1fc520');
