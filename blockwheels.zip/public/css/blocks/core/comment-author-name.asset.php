<?php return array('dependencies' => array(), 'version' => 'abee9344919b89a5203b');
