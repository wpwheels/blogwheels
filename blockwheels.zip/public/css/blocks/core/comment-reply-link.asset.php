<?php return array('dependencies' => array(), 'version' => '6a999309fd099ad5cf3b');
