<?php return array('dependencies' => array(), 'version' => '8059c4b4e77ae2cf4fae');
