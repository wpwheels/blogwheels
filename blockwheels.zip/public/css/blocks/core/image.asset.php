<?php return array('dependencies' => array(), 'version' => '41cd90e171d53d4b9f13');
