<?php return array('dependencies' => array(), 'version' => '8c368a67aed01661b7bf');
