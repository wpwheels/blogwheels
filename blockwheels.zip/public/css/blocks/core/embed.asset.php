<?php return array('dependencies' => array(), 'version' => 'a4a13f891d9651736bfc');
