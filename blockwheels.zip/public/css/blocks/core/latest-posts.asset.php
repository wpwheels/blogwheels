<?php return array('dependencies' => array(), 'version' => '3bf1098740616dc92dd2');
