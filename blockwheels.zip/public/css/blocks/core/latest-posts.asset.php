<?php return array('dependencies' => array(), 'version' => '0645555ea98cd2186bea');
