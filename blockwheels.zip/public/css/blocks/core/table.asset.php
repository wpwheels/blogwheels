<?php return array('dependencies' => array(), 'version' => '2e2619409f99007ecac3');
