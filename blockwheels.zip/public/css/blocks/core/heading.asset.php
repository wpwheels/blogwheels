<?php return array('dependencies' => array(), 'version' => '3c2a58fddbe9727e803a');
