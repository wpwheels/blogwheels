<?php return array('dependencies' => array(), 'version' => 'c8e78903ffbbd5a4b89f');
