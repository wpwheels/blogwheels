<?php return array('dependencies' => array(), 'version' => 'e3ebf13b87a755a19410');
