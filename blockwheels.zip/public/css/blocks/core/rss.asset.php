<?php return array('dependencies' => array(), 'version' => 'c30333deb4bdac1167f5');
