<?php return array('dependencies' => array(), 'version' => 'ff6809ad487e622df872');
