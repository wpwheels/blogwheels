<?php return array('dependencies' => array(), 'version' => '9a843f061b58f56b12cf');
