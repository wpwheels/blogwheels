<?php return array('dependencies' => array(), 'version' => '1eb4812f0c16c0a214ad');
