<?php return array('dependencies' => array(), 'version' => '27dd4fed698b424b52c1');
