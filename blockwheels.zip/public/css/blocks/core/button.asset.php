<?php return array('dependencies' => array(), 'version' => '407709114122d0fb6157');
