<?php return array('dependencies' => array(), 'version' => '72362be98b21658a45bd');
