<?php return array('dependencies' => array(), 'version' => 'e9accf10c455b21aa375');
