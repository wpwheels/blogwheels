<?php return array('dependencies' => array(), 'version' => 'b3d909d1a3d3c2da6dc3');
