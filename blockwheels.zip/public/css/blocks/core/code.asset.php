<?php return array('dependencies' => array(), 'version' => '4ef8922d3c72da61514a');
