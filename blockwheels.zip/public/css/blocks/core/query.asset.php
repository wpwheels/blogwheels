<?php return array('dependencies' => array(), 'version' => '8a5b68f3e0f29ab516cb');
