<?php return array('dependencies' => array(), 'version' => 'f9ec7cb3a65626c5740c');
