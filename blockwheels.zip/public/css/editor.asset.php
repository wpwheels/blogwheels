<?php return array('dependencies' => array(), 'version' => 'fd2de87a09acf02ede52');
