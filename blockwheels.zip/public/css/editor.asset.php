<?php return array('dependencies' => array(), 'version' => '55a53a6c25ac319d0509');
