<?php return array('dependencies' => array(), 'version' => '4558bb4e0555a1e2e4db');
