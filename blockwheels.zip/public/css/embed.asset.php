<?php return array('dependencies' => array(), 'version' => 'cdd7bea8829f7dc0ae0c');
